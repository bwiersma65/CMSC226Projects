//
//  reports.h
//  Semester Project
//
//  Created by Ben Wiersma on 2/23/20.
//  Copyright © 2020 Ben Wiersma. All rights reserved.
//

#ifndef reports_h
#define reports_h

int reports();
void repListing();
void repWholesale();
void repRetail();
void repQty();
void repCost();
void repAge();

#endif /* reports_h */
