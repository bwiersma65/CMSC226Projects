//
//  invmenu.h
//  Semester Project
//
//  Created by Ben Wiersma on 2/23/20.
//  Copyright © 2020 Ben Wiersma. All rights reserved.
//

#ifndef invmenu_h
#define invmenu_h

int invMenu();
void lookUpBook();
void addBook();
void editBook();
void deleteBook();

#endif /* invmenu_h */
