//
//  bookinfo.h
//  Semester Project
//
//  Created by Ben Wiersma on 2/23/20.
//  Copyright © 2020 Ben Wiersma. All rights reserved.
//

#ifndef bookinfo_h
#define bookinfo_h

using namespace std;

void bookInfo(char[], char[], char[], char[], char[], int, double, double);
void strUpper(char *);

#endif /* bookinfo_h */
